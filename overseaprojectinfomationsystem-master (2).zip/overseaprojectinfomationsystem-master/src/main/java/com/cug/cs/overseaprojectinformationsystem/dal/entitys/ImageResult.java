package com.cug.cs.overseaprojectinformationsystem.dal.entitys;

import lombok.Data;


@Data
public class ImageResult {
    String img;
    String code;
}