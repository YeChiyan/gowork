package com.cug.cs.overseaprojectinformationsystem.bean.bo;

import lombok.Data;

/**
 * @description: TODO
 * @author: ShengHui
 * @date: 2023-10-17  01:27
 */
@Data
public class CenterListVO {
    private Integer id;
    private String centerName;
    private Boolean deleted;
}
