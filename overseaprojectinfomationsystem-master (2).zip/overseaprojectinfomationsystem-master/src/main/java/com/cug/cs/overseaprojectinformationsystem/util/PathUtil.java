package com.cug.cs.overseaprojectinformationsystem.util;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * @className: PathUtil
 * @author: Zhangz
 * @description: TODO 设置路径
 * @date: 2023/11/24 20:06
 * @version: 1.0
 */
public class PathUtil {
    public static String getPath(){
        return "E:\\a_java\\ospf\\src\\main\\resources\\";
    }
}
